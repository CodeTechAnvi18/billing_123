package com.billing.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billing.entity.Payment;
import com.billing.repository.BillingRepository;


@Service
public class BillingService {
	
	@Autowired
	private BillingRepository billingRepo;
	
	  public Payment createPayment(Payment payment) {
	        return billingRepo.save(payment);
	    }

	    public List<Payment> getPaymentsByDate(LocalDate date) {
	        return billingRepo.findByPaymentDate(date);
	    }

	    public Optional<Payment> getPaymentById(Long paymentId) {
	        return billingRepo.findById(paymentId);
	    }
	    
	    public List<Payment> getAllPayments() {
	        return billingRepo.findAll();  // Assuming paymentRepository is a JpaRepository or similar
	    }

	    public Payment refundPayment(Long paymentId, double amount) {
	        Payment payment = billingRepo.findById(paymentId)
	                .orElseThrow(() -> new RuntimeException("Payment not found"));
	        payment.setAmount(payment.getAmount() - amount); // Adjust the amount
	        return billingRepo.save(payment);
	    }

	    public void deletePayment(Long paymentId) {
	    	billingRepo.deleteById(paymentId);
	    }
	}











