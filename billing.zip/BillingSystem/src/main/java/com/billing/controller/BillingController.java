package com.billing.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billing.entity.Payment;
import com.billing.service.BillingService;



import jakarta.validation.Valid;

@RestController
@RequestMapping("/bill")
public class BillingController {
	

	    @Autowired
	    private BillingService billingService;

	    @PostMapping
	    public ResponseEntity<Payment> createPayment(@Valid @RequestBody Payment payment) {
	        return ResponseEntity.ok(billingService.createPayment(payment));
	    }

	    @GetMapping
	    public ResponseEntity<List<Payment>> getPaymentsByDate(@RequestParam("date") String date) {
	        return ResponseEntity.ok(billingService.getPaymentsByDate(LocalDate.parse(date)));
	    }
	    
	    @GetMapping("/all")
	    public ResponseEntity<List<Payment>> getAllPayments() {
	        return ResponseEntity.ok(billingService.getAllPayments());
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Payment> getPaymentById(@PathVariable Long id) {
	        return billingService.getPaymentById(id)
	                .map(ResponseEntity::ok)
	                .orElse(ResponseEntity.notFound().build());
	    }

	    @PutMapping("/{id}/refund")
	    public ResponseEntity<Payment> refundPayment(@PathVariable Long id, @RequestParam double amount) {
	        return ResponseEntity.ok(billingService.refundPayment(id, amount));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {
	        billingService.deletePayment(id);
	        return ResponseEntity.noContent().build();
	    }
	}
