package com.billing.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billing.entity.Payment;

public interface BillingRepository extends JpaRepository<Payment, Long> {
	
	List<Payment> findByPaymentDate(LocalDate date);

}
